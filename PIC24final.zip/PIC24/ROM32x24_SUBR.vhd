----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    17:29:36 03/26/2025 
-- Design Name: 
-- Module Name:    ROM32x24 - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ROM32x24 is
    Port ( Addr : in  STD_LOGIC_VECTOR (4 downto 0);
           Data : out  STD_LOGIC_VECTOR (23 downto 0));
end ROM32x24;

architecture ROM32x24_arch of ROM32x24 is

-- The following code must appear before the "begin" keyword in the architecture
-- body.

    type tROM is array (0 to 31) of std_logic_vector (23 downto 0);
    constant ROM : tROM :=(
						      x"808101",-- mov 0x1020, w1 ;INW0=001f  
                        x"808112",-- mov 0x1022, w2 ;INW1=8000
                        x"1081FF",-- subr w1, #31, w3
                        x"11027F",-- subr w2, #31, w4
                        x"888123",-- mov w3, 0x1024
                        x"888124",-- mov w4, 0x1026
                        x"37FFF9",-- bra LOOP
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
                        x"000000",
								x"000000",
								x"000000"
                        );			


begin

Data <= ROM(conv_integer(Addr));

end ROM32x24_arch;

