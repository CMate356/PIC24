----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    23:25:17 03/31/2025 
-- Design Name: 
-- Module Name:    ALU - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU is
    Port ( RdData1 : in  STD_LOGIC_VECTOR (15 downto 0);
           RdData2 : in  STD_LOGIC_VECTOR (15 downto 0);
           ALUOP : in  STD_LOGIC_VECTOR (2 downto 0);
           Y : out  STD_LOGIC_VECTOR (15 downto 0);
			  Z : out STD_LOGIC;
			  N : out STD_LOGIC;
			  OV : out STD_LOGIC;
			  C : out STD_LOGIC;
			  CE_NF : in STD_LOGIC;
			  CE_OVF : in STD_LOGIC;
			  CE_ZF : in STD_LOGIC;
			  CE_CF : in STD_LOGIC;
			  Clock : in STD_LOGIC;
			  Lit5 : in  STD_LOGIC_VECTOR (4 downto 0)
			  );
end ALU;

architecture Behavioral of ALU is
    signal OP1    : std_logic_vector(15 downto 0);
    signal OP2    : std_logic_vector(15 downto 0);
	 signal sY 		: std_logic_vector(16 downto 0);
	 signal sZ : std_logic;
	 signal sOV: std_logic;
	 signal sINC: std_logic_vector(16 downto 0);
	 signal sBTG: std_logic_vector(16 downto 0);
begin
    OP1 <= RdData1;
    OP2 <= RdData2;
	 sINC <= ('0'&OP2(15 downto 0 )) + ('0'&x"0001") ;
	 sBTG <= ('0'&OP1) xor "00000000000001000";
			  
	 Y<=sY(15 downto 0);
	 N<=sY(15) when rising_edge(Clock) and CE_NF='1';
    
    with ALUOP select
        sY <=('0'&OP1) + ('0'&OP2) when "000",--ADD Wb, Ws, Wd 
             ('0'&OP1) - ('1'&OP2) when "001",--SUB Wb, Ws, Wd
             ('0'&OP1) and ('0'&OP2) when "010",--AND Wb, Ws, Wd
             ('0'&OP1) or  ('0'&OP2) when "011",--IOR Wb, Ws, Wd
				 (sBTG)when "100",-- BTG Ws, #bit4  xor x"0010" 
              sINC when "101",-- INC Ws, Wd 
             ("00000000000000000") when "110",-- CLR Wd
             ("000000000000" & Lit5) - ('1' & OP1) when "111",-- SUBR Wb, #lit5, Wd
				 (others => '0') when others;	 
	
	sZ<='1' when sY(15 downto 0)=x"0000"
		 else '0';	
		 
	Z<= sZ when CE_ZF='1' and rising_edge(Clock);
		 
	sOV<='1' when ((ALUOP="000" AND ((sY(15)='1' AND OP1(15)='0' AND OP2(15)='0') OR(sY(15)='0' AND OP1(15)='1' AND OP2(15)='1')))--for add
				OR (ALUOP="001" AND ((sY(15)='1' AND OP1(15)='0' AND OP2(15)='1') OR(sY(15)='0' AND OP1(15)='1' AND OP2(15)='0')))--for sub
				OR (ALUOP="111" AND (sY(15)='1' AND OP1(15)='1'))--for subr
				OR (ALUOP="101" AND (sY(15)='0' AND OP2(15)='1')))--for inc
				else '0';
				
	OV<=sOV when CE_OVF='1' and rising_edge(Clock);
	C<=sY(16) when rising_edge(Clock) and CE_CF='1';
	
end Behavioral;

