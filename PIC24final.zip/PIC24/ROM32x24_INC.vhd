----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    17:29:36 03/26/2025 
-- Design Name: 
-- Module Name:    ROM32x24 - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ROM32x24 is
    Port ( Addr : in  STD_LOGIC_VECTOR (4 downto 0);
           Data : out  STD_LOGIC_VECTOR (23 downto 0));
end ROM32x24;

architecture ROM32x24_arch of ROM32x24 is

-- The following code must appear before the "begin" keyword in the architecture
-- body.

    type tROM is array (0 to 31) of std_logic_vector (23 downto 0);
    constant ROM : tROM :=(
 
							x"808101",--mov 0x1020, w1  ; INW0 = 7FFE
							x"808112",-- mov 0x1022, w2 ; INW1 = 7FFF
							x"E80081",--inc w1 ,w1  ; w1 = 7fff; n=0 
							x"330010", --bra N ,STOP ; N=1 STOP
							x"E80081", --  inc w1,w1 ; w1 = 8000;> n=1 c,ov,z = 0
							x"888121", -- mov w1 , 0x1024 
							x"330001",--bra N , NEXT ; N=1 -> NEXT ; N =0 STOP 
							x"37000C",  -- bra STOP 
							
							x"408182",--add w1, w2, w3 ; w3 = ffff -> c,ov ,z =0 
							x"31000A",-- bra C, STOP
							x"300009",-- bra OV , STOP
							x"320008",--bra Z , STOP 
							x"E80183",--inc w3,w3 ; w3 =  1 0000 => c , ov , z = 1 
							x"310001",-- bra C, ZF 
							x"370005",--bra STOP ; 
			--ZF : 
							x"320001",--bra Z, OVF 
							x"370003",--bra STOP 					
		   --OVF  :    
							x"E80102", --inc w2,w2 ; W2= 8000 ov = 1
							x"300002",--bra  OV , END
							x"370000",--bra STOP				
			--STOP  : 
							x"37FFFF",--bra STOP 							
		   --END : 		
							x"37FFEA",--bra LOOP 		
							x"000000",
							x"000000",
							x"000000",
							x"000000",
							x"000000",
							x"000000",
							x"000000",
							x"000000",
							x"000000",
							x"000000"
							);  
begin

Data <= ROM(conv_integer(Addr));

end ROM32x24_arch;
