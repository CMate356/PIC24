VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan3"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL Clock
        SIGNAL New_PC(5:0)
        SIGNAL PC(5:0)
        SIGNAL PC(5:1)
        SIGNAL Instr(23:0)
        SIGNAL RegDest
        SIGNAL Instr(3:0)
        SIGNAL Instr(10:7)
        SIGNAL Instr(18:15)
        SIGNAL RegWr
        SIGNAL XLXN_6(15:0)
        SIGNAL XLXN_9(15:0)
        SIGNAL XLXN_10(15:0)
        SIGNAL XLXN_11(15:0)
        SIGNAL ALUOP(2:0)
        SIGNAL CE_NF
        SIGNAL CE_OVF
        SIGNAL CE_ZF
        SIGNAL CE_CF
        SIGNAL Z
        SIGNAL OV
        SIGNAL C
        SIGNAL N
        SIGNAL MemWr
        SIGNAL INW0(15:0)
        SIGNAL INW1(15:0)
        SIGNAL Instr(8:4)
        SIGNAL XLXN_27(15:0)
        SIGNAL OUTW0(15:0)
        SIGNAL Mem2Reg
        SIGNAL Instr(23:19)
        SIGNAL Branch
        SIGNAL Instr(4:0)
        SIGNAL Instr(18:16)
        SIGNAL XLXN_65(3:0)
        SIGNAL Instr(16)
        PORT Input Clock
        PORT Output Z
        PORT Output OV
        PORT Output C
        PORT Output N
        PORT Input INW0(15:0)
        PORT Input INW1(15:0)
        PORT Output OUTW0(15:0)
        BEGIN BLOCKDEF PC_Update
            TIMESTAMP 2026 1 7 20 43 18
            LINE N 64 128 0 128 
            LINE N 64 192 0 192 
            LINE N 64 256 0 256 
            LINE N 64 320 0 320 
            RECTANGLE N 0 372 64 396 
            LINE N 64 384 0 384 
            RECTANGLE N 0 -140 64 -116 
            LINE N 0 -128 64 -128 
            LINE N 432 -64 368 -64 
            RECTANGLE N 368 -12 432 12 
            LINE N 432 0 368 0 
            RECTANGLE N 368 52 432 76 
            LINE N 432 64 368 64 
            RECTANGLE N 64 -156 368 432 
        END BLOCKDEF
        BEGIN BLOCKDEF ProgCnt
            TIMESTAMP 2026 1 7 21 48 7
            LINE N 64 32 0 32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            RECTANGLE N 64 -128 320 64 
        END BLOCKDEF
        BEGIN BLOCKDEF ROM32x24
            TIMESTAMP 2026 1 7 20 43 34
            RECTANGLE N 64 -64 320 0 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF MUX2V5
            TIMESTAMP 2026 1 7 20 43 43
            RECTANGLE N 64 -192 320 0 
            RECTANGLE N 320 -172 384 -148 
            LINE N 320 -160 384 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF File_Regs
            TIMESTAMP 2026 1 7 21 48 35
            LINE N 64 160 0 160 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 416 -428 480 -404 
            LINE N 416 -416 480 -416 
            RECTANGLE N 0 -12 64 12 
            LINE N 64 0 0 0 
            RECTANGLE N 416 -364 480 -340 
            LINE N 416 -352 480 -352 
            RECTANGLE N 0 84 64 108 
            LINE N 64 96 0 96 
            LINE N 64 -352 0 -352 
            RECTANGLE N 64 -448 416 196 
        END BLOCKDEF
        BEGIN BLOCKDEF ALU
            TIMESTAMP 2026 1 7 21 49 24
            LINE N 64 416 0 416 
            RECTANGLE N 0 340 64 364 
            LINE N 64 352 0 352 
            LINE N 64 32 0 32 
            LINE N 64 96 0 96 
            LINE N 64 160 0 160 
            LINE N 64 224 0 224 
            LINE N 320 32 384 32 
            LINE N 320 96 384 96 
            LINE N 320 160 384 160 
            LINE N 320 224 384 224 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            RECTANGLE N 64 -320 320 464 
        END BLOCKDEF
        BEGIN BLOCKDEF DataMem
            TIMESTAMP 2026 1 7 21 50 12
            LINE N 64 208 0 208 
            RECTANGLE N 0 68 64 92 
            LINE N 64 80 0 80 
            RECTANGLE N 0 132 64 156 
            LINE N 64 144 0 144 
            RECTANGLE N 384 132 448 156 
            LINE N 384 144 448 144 
            LINE N 64 16 0 16 
            RECTANGLE N 0 -156 64 -132 
            LINE N 64 -144 0 -144 
            RECTANGLE N 384 -156 448 -132 
            LINE N 384 -144 448 -144 
            RECTANGLE N 0 -92 64 -68 
            LINE N 64 -80 0 -80 
            RECTANGLE N 64 -240 384 252 
        END BLOCKDEF
        BEGIN BLOCKDEF MUX2V16
            TIMESTAMP 2026 1 7 20 42 15
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -172 384 -148 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF ctrl
            TIMESTAMP 2026 1 9 9 47 3
            LINE N 64 352 0 352 
            LINE N 320 96 384 96 
            LINE N 320 160 384 160 
            LINE N 320 224 384 224 
            LINE N 320 288 384 288 
            LINE N 320 32 384 32 
            RECTANGLE N 0 -364 64 -340 
            LINE N 64 -352 0 -352 
            LINE N 320 -288 384 -288 
            LINE N 320 -224 384 -224 
            LINE N 320 -160 384 -160 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
            RECTANGLE N 64 -384 320 384 
        END BLOCKDEF
        BEGIN BLOCK U_PC ProgCnt
            PIN New_PC(5:0) New_PC(5:0)
            PIN PC(5:0) PC(5:0)
            PIN Clock Clock
        END BLOCK
        BEGIN BLOCK U_ROM ROM32x24
            PIN Addr(4:0) PC(5:1)
            PIN Data(23:0) Instr(23:0)
        END BLOCK
        BEGIN BLOCK U_New_PC PC_Update
            PIN Branch Branch
            PIN C C
            PIN N N
            PIN Z Z
            PIN OV OV
            PIN Offset(4:0) Instr(4:0)
            PIN Branch_Type(2:0) Instr(18:16)
            PIN PC(5:0) PC(5:0)
            PIN New_PC(5:0) New_PC(5:0)
        END BLOCK
        BEGIN BLOCK U_MUXRegD MUX2V5
            PIN Sel RegDest
            PIN I0(3:0) Instr(3:0)
            PIN I1(3:0) Instr(10:7)
            PIN Y(3:0) XLXN_65(3:0)
        END BLOCK
        BEGIN BLOCK U_Regs File_Regs
            PIN WrEn RegWr
            PIN RdReg1(3:0) Instr(18:15)
            PIN RdReg2(3:0) Instr(3:0)
            PIN WrReg(3:0) XLXN_65(3:0)
            PIN WRData(15:0) XLXN_11(15:0)
            PIN RdData1(15:0) XLXN_6(15:0)
            PIN RdData2(15:0) XLXN_27(15:0)
            PIN Clock Clock
        END BLOCK
        BEGIN BLOCK XLXI_1 ALU
            PIN CE_NF CE_NF
            PIN CE_OVF CE_OVF
            PIN CE_ZF CE_ZF
            PIN CE_CF CE_CF
            PIN RdData1(15:0) XLXN_6(15:0)
            PIN RdData2(15:0) XLXN_27(15:0)
            PIN ALUOP(2:0) ALUOP(2:0)
            PIN Lit5(4:0) Instr(4:0)
            PIN Z Z
            PIN N N
            PIN OV OV
            PIN C C
            PIN Y(15:0) XLXN_9(15:0)
            PIN Clock Clock
        END BLOCK
        BEGIN BLOCK XLXI_2 DataMem
            PIN Wr MemWr
            PIN INW0(15:0) INW0(15:0)
            PIN INW1(15:0) INW1(15:0)
            PIN Addr(4:0) Instr(8:4)
            PIN DataIn(15:0) XLXN_27(15:0)
            PIN OUTW0(15:0) OUTW0(15:0)
            PIN DataOut(15:0) XLXN_10(15:0)
            PIN Clock Clock
        END BLOCK
        BEGIN BLOCK XLXI_3 MUX2V16
            PIN Sel Mem2Reg
            PIN I0(15:0) XLXN_9(15:0)
            PIN I1(15:0) XLXN_10(15:0)
            PIN Y(15:0) XLXN_11(15:0)
        END BLOCK
        BEGIN BLOCK XLXI_4 ctrl
            PIN OP(4:0) Instr(23:19)
            PIN MemWr MemWr
            PIN Mem2Reg Mem2Reg
            PIN RegWr RegWr
            PIN RegDest RegDest
            PIN Branch Branch
            PIN CE_NF CE_NF
            PIN CE_ZF CE_ZF
            PIN CE_OVF CE_OVF
            PIN CE_CF CE_CF
            PIN ALUOP(2:0) ALUOP(2:0)
            PIN SEL Instr(16)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 5440 3520
        BEGIN INSTANCE U_ROM 1104 1312 R0
            BEGIN DISPLAY 144 -168 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BUSTAP 976 1280 1072 1280
        BEGIN BRANCH PC(5:1)
            WIRE 1072 1280 1088 1280
            WIRE 1088 1280 1104 1280
            BEGIN DISPLAY 1088 1280 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Instr(23:0)
            WIRE 1488 1280 1584 1280
            WIRE 1584 1280 1584 1296
            WIRE 1584 1296 1584 1360
            WIRE 1584 1360 1584 1456
            WIRE 1584 1456 1584 1520
            WIRE 1584 1520 1584 1744
            WIRE 1584 1744 1584 1824
            WIRE 1584 1824 1584 1952
            WIRE 1584 1952 1584 2640
            WIRE 1584 2640 1584 2656
            WIRE 1584 2656 1584 2752
            WIRE 1584 352 1584 608
            WIRE 1584 608 1584 944
            WIRE 1584 944 1584 1280
            BEGIN DISPLAY 1584 1360 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH RegDest
            WIRE 1664 1584 1696 1584
            WIRE 1696 1584 1760 1584
            BEGIN DISPLAY 1696 1584 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BUSTAP 1584 1456 1680 1456
        BUSTAP 1584 1520 1680 1520
        BEGIN BRANCH Instr(3:0)
            WIRE 1680 1456 1696 1456
            WIRE 1696 1456 1760 1456
            WIRE 1696 1312 1696 1456
            WIRE 1696 1312 2432 1312
            BEGIN DISPLAY 1696 1456 ATTR Name
                ALIGNMENT SOFT-TCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Instr(10:7)
            WIRE 1680 1520 1696 1520
            WIRE 1696 1520 1760 1520
            BEGIN DISPLAY 1696 1520 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE U_Regs 2432 1472 R0
            BEGIN DISPLAY 112 -536 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BUSTAP 1584 1296 1680 1296
        BEGIN BRANCH Instr(18:15)
            WIRE 1680 1296 1696 1296
            WIRE 1696 1248 1696 1296
            WIRE 1696 1248 2064 1248
            WIRE 2064 1248 2432 1248
            BEGIN DISPLAY 2064 1248 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH RegWr
            WIRE 2384 1120 2400 1120
            WIRE 2400 1120 2432 1120
            BEGIN DISPLAY 2400 1120 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE U_New_PC 480 608 R0
            BEGIN DISPLAY 144 -264 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE U_MUXRegD 1760 1616 R0
            BEGIN DISPLAY 112 -280 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE XLXI_2 4080 1248 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3 4832 1168 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_4 1760 2304 R0
        END INSTANCE
        BEGIN BRANCH XLXN_6(15:0)
            WIRE 2912 1056 3296 1056
        END BRANCH
        BEGIN INSTANCE XLXI_1 3296 1344 R0
        END INSTANCE
        BEGIN BRANCH XLXN_9(15:0)
            WIRE 3680 1248 3808 1248
            WIRE 3808 864 3808 1248
            WIRE 3808 864 4688 864
            WIRE 4688 864 4688 1072
            WIRE 4688 1072 4832 1072
        END BRANCH
        BEGIN BRANCH XLXN_10(15:0)
            WIRE 4528 1392 4704 1392
            WIRE 4704 1136 4704 1392
            WIRE 4704 1136 4832 1136
        END BRANCH
        BEGIN BRANCH XLXN_11(15:0)
            WIRE 2400 1568 2432 1568
            WIRE 2400 1568 2400 1808
            WIRE 2400 1808 5216 1808
            WIRE 5216 1008 5296 1008
            WIRE 5296 1008 5296 1248
            WIRE 5216 1248 5296 1248
            WIRE 5216 1248 5216 1808
        END BRANCH
        BEGIN BRANCH ALUOP(2:0)
            WIRE 3216 1248 3248 1248
            WIRE 3248 1248 3296 1248
            BEGIN DISPLAY 3248 1248 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_NF
            WIRE 3216 1376 3248 1376
            WIRE 3248 1376 3296 1376
            BEGIN DISPLAY 3248 1376 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_OVF
            WIRE 3216 1440 3248 1440
            WIRE 3248 1440 3296 1440
            BEGIN DISPLAY 3248 1440 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_ZF
            WIRE 3216 1504 3232 1504
            WIRE 3232 1504 3296 1504
            BEGIN DISPLAY 3232 1504 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_CF
            WIRE 3216 1568 3248 1568
            WIRE 3248 1568 3296 1568
            BEGIN DISPLAY 3248 1568 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Z
            WIRE 3680 1376 3712 1376
        END BRANCH
        BEGIN BRANCH N
            WIRE 3680 1440 3712 1440
        END BRANCH
        BEGIN BRANCH OV
            WIRE 3680 1504 3712 1504
        END BRANCH
        BEGIN BRANCH C
            WIRE 3680 1568 3712 1568
        END BRANCH
        IOMARKER 3712 1376 Z R0 28
        IOMARKER 3712 1440 N R0 28
        IOMARKER 3712 1504 OV R0 28
        IOMARKER 3712 1568 C R0 28
        BEGIN BRANCH MemWr
            WIRE 4032 1264 4064 1264
            WIRE 4064 1264 4080 1264
            BEGIN DISPLAY 4064 1264 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH INW0(15:0)
            WIRE 4032 1104 4080 1104
        END BRANCH
        BEGIN BRANCH INW1(15:0)
            WIRE 4032 1168 4080 1168
        END BRANCH
        BEGIN BRANCH Instr(8:4)
            WIRE 1680 1824 3888 1824
            WIRE 3888 1328 3888 1824
            WIRE 3888 1328 3952 1328
            WIRE 3952 1328 4032 1328
            WIRE 4032 1328 4080 1328
            BEGIN DISPLAY 3952 1328 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_27(15:0)
            WIRE 2912 1120 3024 1120
            WIRE 3024 1120 3296 1120
            WIRE 3024 1120 3024 1920
            WIRE 3024 1920 3936 1920
            WIRE 3936 1392 3936 1920
            WIRE 3936 1392 4032 1392
            WIRE 4032 1392 4080 1392
        END BRANCH
        BEGIN BRANCH OUTW0(15:0)
            WIRE 4528 1104 4560 1104
        END BRANCH
        IOMARKER 4032 1104 INW0(15:0) R180 28
        IOMARKER 4032 1168 INW1(15:0) R180 28
        IOMARKER 4560 1104 OUTW0(15:0) R0 28
        BEGIN BRANCH Mem2Reg
            WIRE 4784 1008 4816 1008
            WIRE 4816 1008 4832 1008
            BEGIN DISPLAY 4816 1008 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BUSTAP 1584 1952 1680 1952
        BEGIN BRANCH Instr(23:19)
            WIRE 1680 1952 1712 1952
            WIRE 1712 1952 1760 1952
            BEGIN DISPLAY 1712 1952 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH MemWr
            WIRE 2144 2016 2160 2016
            WIRE 2160 2016 2192 2016
            BEGIN DISPLAY 2160 2016 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Mem2Reg
            WIRE 2144 2080 2160 2080
            WIRE 2160 2080 2192 2080
            BEGIN DISPLAY 2160 2080 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH RegWr
            WIRE 2144 2144 2160 2144
            WIRE 2160 2144 2192 2144
            BEGIN DISPLAY 2160 2144 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH RegDest
            WIRE 2144 2208 2160 2208
            WIRE 2160 2208 2192 2208
            BEGIN DISPLAY 2160 2208 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ALUOP(2:0)
            WIRE 2144 2272 2176 2272
            WIRE 2176 2272 2192 2272
            BEGIN DISPLAY 2176 2272 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Branch
            WIRE 2144 2336 2160 2336
            WIRE 2160 2336 2192 2336
            BEGIN DISPLAY 2160 2336 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_NF
            WIRE 2144 2400 2160 2400
            WIRE 2160 2400 2192 2400
            BEGIN DISPLAY 2160 2400 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_ZF
            WIRE 2144 2464 2160 2464
            WIRE 2160 2464 2192 2464
            BEGIN DISPLAY 2160 2464 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_OVF
            WIRE 2144 2528 2160 2528
            WIRE 2160 2528 2192 2528
            BEGIN DISPLAY 2160 2528 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CE_CF
            WIRE 2144 2592 2160 2592
            WIRE 2160 2592 2192 2592
            BEGIN DISPLAY 2160 2592 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Branch
            WIRE 912 544 944 544
            WIRE 944 544 976 544
            BEGIN DISPLAY 944 544 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Instr(4:0)
            WIRE 912 608 1248 608
            WIRE 1248 608 1488 608
            BEGIN DISPLAY 1248 608 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH C
            WIRE 400 736 432 736
            WIRE 432 736 480 736
            BEGIN DISPLAY 432 736 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH N
            WIRE 400 800 432 800
            WIRE 432 800 480 800
            BEGIN DISPLAY 432 800 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Z
            WIRE 400 864 432 864
            WIRE 432 864 480 864
            BEGIN DISPLAY 432 864 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH OV
            WIRE 384 928 416 928
            WIRE 416 928 480 928
            BEGIN DISPLAY 416 928 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BUSTAP 1584 608 1488 608
        BUSTAP 1584 944 1488 944
        BEGIN BRANCH Instr(18:16)
            WIRE 416 992 480 992
            WIRE 416 992 416 1072
            WIRE 416 1072 1280 1072
            WIRE 1280 1072 1392 1072
            WIRE 1392 944 1392 1072
            WIRE 1392 944 1488 944
            BEGIN DISPLAY 1280 1072 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH PC(5:0)
            WIRE 880 1200 976 1200
            WIRE 976 1200 976 1280
            WIRE 976 1280 976 1360
            WIRE 912 672 976 672
            WIRE 976 672 976 1008
            WIRE 976 1008 976 1200
            BEGIN DISPLAY 976 1008 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH New_PC(5:0)
            WIRE 240 480 480 480
            WIRE 240 480 240 896
            WIRE 240 896 240 1264
            WIRE 240 1264 496 1264
            BEGIN DISPLAY 240 896 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE U_PC 496 1296 R0
            BEGIN DISPLAY 112 152 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        IOMARKER 432 1328 Clock R180 28
        BEGIN BRANCH Clock
            WIRE 432 1328 448 1328
            WIRE 448 1328 448 1408
            WIRE 432 1408 448 1408
            WIRE 432 1408 432 1456
            WIRE 432 1456 464 1456
            WIRE 464 1328 464 1456
            WIRE 464 1328 496 1328
        END BRANCH
        BEGIN BRANCH Clock
            WIRE 2368 1632 2416 1632
            WIRE 2416 1632 2432 1632
            BEGIN DISPLAY 2416 1632 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Clock
            WIRE 3216 1760 3280 1760
            WIRE 3280 1760 3296 1760
            BEGIN DISPLAY 3280 1760 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Clock
            WIRE 4032 1456 4064 1456
            WIRE 4064 1456 4080 1456
            BEGIN DISPLAY 4064 1456 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Instr(4:0)
            WIRE 1680 1744 2304 1744
            WIRE 2304 1744 2480 1744
            WIRE 2480 1696 2480 1744
            WIRE 2480 1696 3296 1696
            BEGIN DISPLAY 2304 1744 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BUSTAP 1584 1824 1680 1824
        BUSTAP 1584 1744 1680 1744
        BEGIN BRANCH XLXN_65(3:0)
            WIRE 2144 1456 2288 1456
            WIRE 2288 1456 2288 1472
            WIRE 2288 1472 2432 1472
        END BRANCH
        BUSTAP 1584 2656 1680 2656
        BEGIN BRANCH Instr(16)
            WIRE 1680 2656 1744 2656
            WIRE 1744 2656 1760 2656
            BEGIN DISPLAY 1744 2656 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
    END SHEET
END SCHEMATIC
