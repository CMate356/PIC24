----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    17:25:59 03/26/2025 
-- Design Name: 
-- Module Name:    PC_Update - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity PC_Update is
    Port ( Offset : in STD_LOGIC_VECTOR(4 downto 0);
			  Branch : in STD_LOGIC;
			  Branch_Type:in STD_LOGIC_VECTOR(2 downto 0);
			  C:in STD_LOGIC;
			  N:in STD_LOGIC;
			  Z:in STD_LOGIC;
			  OV:in STD_LOGIC;
		     PC : in  STD_LOGIC_VECTOR (5 downto 0);
           New_PC : out  STD_LOGIC_VECTOR (5 downto 0));
end PC_Update;

architecture Behavioral of PC_Update is
signal PC_p2 : std_logic_vector (5 downto 0);
 signal depl : std_logic_vector (5 downto 0);
begin
    depl(0) <= '0';
	 depl(5 downto 1)<=offset;

    PC_p2 <= PC + 2;
    New_PC <= PC_p2 + depl when(Branch = '1' and 
((Branch_Type="111") or (Branch_Type="000" and OV='1') or (Branch_Type="001" and C='1') or (Branch_Type="011" and N='1') or (Branch_Type="010" and Z='1')))
	 else PC_p2;
					 
end Behavioral;

