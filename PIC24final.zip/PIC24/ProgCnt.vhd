----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    17:22:13 03/26/2025 
-- Design Name: 
-- Module Name:    ProgCnt - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ProgCnt is
    Port( Clock : in  STD_LOGIC;
           New_PC : in  STD_LOGIC_VECTOR (5 downto 0);
           PC : out  STD_LOGIC_VECTOR (5 downto 0) := "000000"
		);
end ProgCnt;

architecture Behavioral of ProgCnt is

begin

PC <= New_PC when rising_edge(Clock);

end Behavioral;

