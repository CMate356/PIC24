----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    17:29:36 03/26/2025 
-- Design Name: 
-- Module Name:    ROM32x24 - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ROM32x24 is
    Port ( Addr : in  STD_LOGIC_VECTOR (4 downto 0);
           Data : out  STD_LOGIC_VECTOR (23 downto 0));
end ROM32x24;

architecture ROM32x24_arch of ROM32x24 is

-- The following code must appear before the "begin" keyword in the architecture
-- body.

    type tROM is array (0 to 31) of std_logic_vector (23 downto 0);
    constant ROM : tROM :=(
				
            x"808101", -- mov 0x1020, w1     ; INW0=ffff
            x"808112", -- mov 0x1022, w2     ; INW1=0001
            x"410382", -- add w2,w2,w7       ; 0002, C=0
            x"310002", -- BRA C, STOP        ; no jump
            x"408182", -- add w1,w2,w3       ; 0000, C=1
            x"310001", -- bra C, END         ; jump to END -- STOP:
            x"37FFFF", -- bra STOP           ; infinite loop -- END:
            x"37FFF8", -- bra LOOP           ; return to start
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000",
            x"000000"
            );
					

begin

Data <= ROM(conv_integer(Addr));

end ROM32x24_arch;

