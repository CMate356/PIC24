----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    23:26:27 03/31/2025 
-- Design Name: 
-- Module Name:    ctrl - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ctrl is
    Port ( OP : in  STD_LOGIC_VECTOR (4 downto 0);
	        SEL : in  STD_LOGIC;
           ALUOP : out  STD_LOGIC_VECTOR (2 downto 0);
           MemWr : out  STD_LOGIC;
           Mem2Reg : out  STD_LOGIC;
           RegWr : out  STD_LOGIC;
           RegDest : out  STD_LOGIC;
			  Branch : out STD_LOGIC;
			  CE_NF : out STD_LOGIC; 
			  CE_ZF : out STD_LOGIC;   
			  CE_OVF : out STD_LOGIC; 
			  CE_CF: out STD_LOGIC
			);
end ctrl;

architecture Behavioral of ctrl is

begin

   CE_OVF <= '1' when OP = b"01000" or OP = b"01010"-- Overflow add/sub 
	           or (OP = b"11101" AND SEL='0') or OP = b"00010"-- INC and SUBR
									else '0'; 
									
	CE_CF <= '1' when OP = b"01000" or OP = b"01010"-- Carry add/sub
	                  or (OP = b"11101" AND SEL='0') --INC Ws, Wd
							or OP =b"00010" --SUBR Wb, #lit5, Wd
									else '0'; 
   								
	CE_ZF <= '1' when OP= b"01000"--ADD Wb, Ws, Wd
						   or 	OP =b"01010" --SUB Wb, Ws, Wd
						   or 	OP =b"01100" --AND Wb, Ws, Wd
						   or 	OP =b"01110" --IOR Wb, Ws, Wd
							or 	(OP = b"11101" AND SEL='0') --INC Ws, Wd
							or 	OP =b"00010" --SUBR Wb, #lit5, Wd
						   else '0';  
						  
  CE_NF <= '1' when OP= b"01000"--ADD Wb, Ws, Wd
						  or 	OP = b"01010"--SUB Wb, Ws, Wd
						  or 	OP =b"01100"--AND Wb, Ws, Wd
						  or 	OP =b"01110"--IOR Wb, Ws, Wd
						  or  (OP = b"11101" AND SEL='0')--INC Ws, Wd
						  or  OP =b"00010"--SUBR Wb, #lit5, Wd
						  else '0';  
						  
	Branch <= '1' when 	OP = b"00110" 
						else '0';
								
	RegDest <= '0' when 	OP= b"10000"--MOV f, Wnd
	               or OP= b"10100"--BTG Ws, #bit4
						else '1'; 
						  
	ALUOP <= "000" when 	OP = b"01000" else --ADD Wb, Ws, Wd
				"001" when 	OP = b"01010" else --SUB Wb, Ws, Wd
				"010" when 	OP = b"01100" else --AND Wb, Ws, Wd
				"011" when 	OP = b"01110" else--IOR Wb, Ws, Wd
            "100" when 	OP = b"10100" else--BTG Ws, #bit4
				"101" when 	(OP = b"11101" AND SEL = '0') else--INC Ws, Wd
				"110" when 	(OP = b"11101" AND SEL = '1') else--CLR Wd
				"111" when 	OP = b"00010" --SUBR Wb, #lit5, Wd
			    else "000"; 
				 
   Mem2Reg <= '1' when OP =b"10000" --MOV f, Wnd
								else '0'; 			
   MemWr <='1' when OP=b"10001" --MOV Wns, f
					else '0';
   RegWr <='0' when OP=b"10001" --MOV Wns, f
			   OR OP=b"00110" --BRA 
				else '1';
				
end Behavioral;

